# Prüfung 0.18 — Direkte Baustellenversorgung und stabile Materialanzeigen

- **17.771 Headless-Prüfungen**: die unveränderten bisherigen 17.337 Prüfungen plus 434 gezielte Logistikprüfungen. `bash scripts/test.sh` vollständig bestanden, einschließlich Import, erstem Haus nach 1.682 simulierten Sekunden ohne geschenkte Ressourcen und Hauptszenenstart.
- Nachgestelltes Unternehmenslevel-8-Profil mit aktiver Holzlinie, zwei LKWs, vollem Stationspuffer, lokalem Bretterausgang, global null Brettern und bezahltem Quartierspark. Ohne Level-10-Automatik oder manuelle Lagerentnahme holen tatsächliche Straßenladungen zwanzig Bretter am Sägewerk und zwei Bauelemente am Lager ab. Erst nach Lieferung und sieben Arbeitsphasen entsteht der echte Park.
- Pro Simulationstakt Erhaltung des Holzäquivalents über gemeinsame und lokale Vorräte, Waren unterwegs, Baustellenquittungen und Ladenverkäufe; keine negativen Mengen oder Überbuchung des gemeinsam gekauften Fuhrparks. Zwei Baustellen teilen fünf echte Bretter in Vierer- und Einser-Ladungen; wiederholtes Anfordern dupliziert nichts. Bauabbruch gibt diese Ladungen genau einmal zurück.
- JSON-Speichern mitten in der direkten Lieferung und anschließende Simulation ergeben denselben vollständigen Zustand wie der ununterbrochene Lauf, numerische Toleranz 1e-8. Insbesondere behalten float-geladene Gebäudereferenzen ihre ausschließliche Zuordnung zur Holzlinie, sodass alte gemeinsame Rezepte nicht zusätzlich laufen.
- Migration alter nicht angeforderter Materialprojekte aktiviert die Versorgung, erhält aber ausdrückliche Pausen, Rechnungen, Fortschritt, Puffer und bestehende Ladungen. Pausierter Bau entnimmt keine neue Ware; eine pausierte Holzlinie darf bereits vorhandene Ausgänge für unabhängige Baustellen abgeben. Unerreichbare Ziele entnehmen kein Material und melden die fehlende Straßenverbindung. Fertige Bausteine werden auch direkt am Steinwerk aufgenommen.
- **138 Desktop-OpenGL-Prüfungen**: 23 UI, 9 Landschaft, 22 bisherige Holz-/Baustellenanzeigen, 27 Verkehr/Touch, 27 Stein und 30 neue gerenderte Logistikprüfungen. Tatsächliche Holz- und Bretterfahrten mit bewusst gleichen numerischen IDs behalten getrennte Modelle. Boards bleiben während des Transports sichtbar, verschwinden nach tatsächlicher Entladung und die Rückfahrt heißt LEER. Erneute Takte schreiben keine zweite Quittung.
- Sägewerk und Möbelwerk besitzen dauerhaft getrennte Ein-/Ausgangssymbole und Zähler; volle und abgeholte Bretter wechseln nicht mehr die Holz-Identität. Ausgangszeilen passen bei 540×960 und 360×640 in ihre Weltanzeigen. Im Baustellenmenü stehen tatsächlicher Ursprung und bereits reservierte ankommende Mengen. Zwei Vorschauen stammen ausschließlich aus aufgebauten Demonstrationsprofilen.
- Android-Installation, Touch-Hardware und mobile Leistung der neuen Version wurden hier nicht auf einem realen Gerät geprüft. Das Update enthält keine vollständige neue Logistiksimulation für sämtliche alten fortgeschrittenen Fabriken oder eine Kollisions-/Ampelsteuerung.

## Historischer Prüfbericht 0.17

# Prüfung 0.17 — Steinrevier und Materialvorschau

- Vollständige Suite mit 231 Regel-, 4.092 Szenen-, 52 Platzierungs-, 42 Werkstatt-, 23 Begleiter-, 30 Alltagsszenen-, 213 Stadt-, 177 Landschafts-, 6.057 Holz-Lieferketten-, 56 Baustellen-, 1.494 Verkehrs-/Touch- und 4.870 neuen Steinprüfungen: **17.337 Headless-Prüfungen**, dazu erster-Haus-Verlauf nach 1.682 simulierten Sekunden ohne Geschenke und Hauptszenenstart. Der abschließende Stein-Test wurde nach der Korrektur wartender LKW-Darstellung erneut ausgeführt.
- Freischaltung erst auf Unternehmenslevel 5, keine Kosten oder Baustelle bei gesperrtem Kauf. Alte Spielstände erhalten null neue Rohstoffe. Atomarer Save-/Load-Weg erhält bezahlte Baupläne und deren ursprüngliche Materialrechnung. Erster Steinbruch lässt sich durch echte Holz-/Bretterlieferungen fertig bauen; ein späterer Ausbau wartet auch auf die letzte fehlende Kies-Einheit.
- Datengetriebene Rezepte, Materialnamen/-werte, Transportgewicht und vorhandene Icons geprüft. Schaufelmaterial wird erst nach dem Graben aus dem begrenzten Vorkommen entnommen; die Mulde erhält es erst beim tatsächlichen Ausschütten. Voller Ausgang und fehlender LKW stoppen die Gewinnung. Neue Felsader wird genau einmal bezahlt und kann einen nicht erschöpften Vorrat nicht überschreiben.
- Rezeptarbeit benötigt reale lokale Eingänge. Verbrauchten Rohstoff hält ein gespeicherter laufender Auftrag, bis daraus die korrekte Ausgabe entsteht. Pausieren hält die Arbeit an. Ein Produktwechsel verändert keine bereits angefangene Charge. Volle Ausgänge verbrauchen keine weiteren Rohstoffe.
- 600 Simulationstakte mit Erhaltung des Gesteinsäquivalents über Vorkommen, Schaufel, Abholmulde, LKW, lokalen Puffer, Arbeitsauftrag und fertige Lagerware. Bausteine entsprechen 3/5 Gestein pro Einheit, Kies 3/4. Jede lokale Kapazität und der gemeinsame gekaufte Fuhrpark werden pro Takt geprüft. Keine negativen Bestände, keine Gutschrift vor Entladung und keine doppelte Warenbuchung.
- Zwei Fahrzeuge führen eine Vierer- und eine Einser-Teilladung aus, ohne den Zielraum doppelt zu reservieren. Wird das Lager während der Fahrt gefüllt, bleibt die Ware auf dem wartenden LKW; nach Freigabe des Platzes wird sie einmal entladen. Unerreichbare Betriebe erzeugen keine Ersatzroute. Aktive Ursprünge und Ziele sind vor Standortänderungen geschützt.
- JSON-Save mitten im Abbau und laufenden Straßenfahrten liefert nach 300 weiteren Sekunden dieselben verschachtelten Daten wie die ununterbrochene Simulation. Numerische Toleranz 1e-8; `last_seen` wird als Wanduhr aus dem Vergleich ausgeschlossen. Mehrere Steinwerke liefern unabhängig Bausteine und Kies. Ein gekaufter LKW bedient über 1.600 Takte sowohl Holzlinie als auch Steinkette. Notmaterial lässt sich unter Geldboostern nicht mit Gewinn weiterverkaufen.
- Desktop OpenGL: **108 Prüfungen** aus 23 UI-, 9 Landschafts-, 22 Holzliefer-/Baustellen-, 27 Verkehrs- und 27 neuen Steinprüfungen. Vier neue Aufnahmen zeigen ausdrücklich aufgebaute, auf legale freie Grundstücke geprüfte Demonstrationsprofile. Keine Nutzerprofile wurden dafür verändert.
- Gerenderte Prüfung: geladene Schaufel, bewegter Oberwagen, unterschiedliche Kipper-/Paletten-Auflieger, echte Füllstände und mobile Produktionswahl. Ein beladener LKW am vollen Lager bleibt auch bei interpolierter Darstellung am Dock stehen. Bauvorschau zeigt die spätere Materialrechnung oberhalb der Bestätigung; Stadtbaustellen ab Level 4 werden bei gültigem Platz nicht mehr durch erst später anzuliefernde Materialien blockiert. Kleines Hochformatfenster geprüft. Touchgesten bleiben synthetische Desktop-Tests; reale Android-Hardware wurde hier nicht verwendet.
- Offen bleiben direkte Schaufelübergabe an einen wartenden Kipper, Steinplatten und zusätzliche Sand-/Metall-/Betonketten, vollständige Fahrzeugidentitäten/Kollisionen und echte mobile Leistungs- und Updateprüfungen. Siehe [Industrie-Masterplan](INDUSTRY-ROADMAP.md).

## Auslieferung 0.17

- APK-Quellstand: `662573b23cb9b3781b2f07085a314161070c4cb8`.
- APK: 58,296,429 Bytes, SHA256 `c0885fa3e9b514e54e04d5765891910262b792af78cf12bf00a37b3799f22c3f`.
- Quell-ZIP: 203 Dateien, 9,994,951 Bytes, SHA256 `163898d035ef3437979e0f899eb10b0d880fc4c4d507f1aba29fa867006911bc`. Jede Datei gegen den Git-Blob des APK-Quellstands geprüft; Release-Dateien sind aus dem Quellarchiv ausgeschlossen.
- Gleiches Zertifikat wie 0.16: `08b5b5b8d6edb6590545fe77f6f14248f6f14256c9edc781989ac41100ff1005`. Versionscode 1700, Speicherformat 1, API 24+, ARM64/ARMv7, v2-Signatur, 16-KB-ZIP-Ausrichtung, Hochformat, GL Compatibility und keine Berechtigungen geprüft. Neue Skripte, SVG-Rohstofficons und `Economy/stone_industry.json` sind enthalten. Die Produktionsdaten wurden direkt aus dem APK gelesen und geprüft. Tests, Build-Helfer und Release-Dateien sind ausgeschlossen.
- Frische unabhängige GitHub-Kopie unter `/workspace/timber-restore-17`: Erstimport, alle **17.337 Headless-Prüfungen**, erster-Haus-Verlauf und Hauptszenenstart bestanden.

- Auch alle **108 OpenGL-Prüfungen** bestehen in der unabhängigen GitHub-Kopie. Die Wiederherstellung ist sauber; Änderungen nach dem APK-Quellstand betreffen ausschließlich Auslieferungsdateien und Dokumentation.
- APK, passende Quell-ZIP und vier neue Vorschauen vom festen Tag `v0.17.0-stone` vollständig per HTTPS mit HTTP 200 heruntergeladen. Alle Dateigrößen und SHA256 stimmen mit Original und unabhängiger GitHub-Wiederherstellung überein. Bericht: [download-verification-17.json](download-verification-17.json).

## Historischer Prüfbericht 0.16

# Prüfung 0.16 — Straßenfracht, Stadtdienste und Finger-Scrollen

- Vollständiger Lauf von `bash scripts/test.sh`: 225 Regel-, 4.092 Szenen-, 52 Platzierungs-, 42 Werkstatt-, 23 Begleiter-, 30 Alltagsszenen-, 213 Stadt-, 177 Landschafts-, 6.057 Lieferketten-, 56 Baustellen- und 1.494 Verkehrs-/Touchprüfungen: **12.461 Headless-Prüfungen**. Dazu der unveränderte erste-Haus-Verlauf nach 1.682 simulierten Sekunden ohne geschenkte Ressourcen und der Hauptszenenstart.
- Alle drei Materialstrecken sind Straßenfracht und teilen den tatsächlich gekauften Fuhrpark einschließlich Rückfahrten mit Bauprojekten. 460 Takte Stoffbilanz und weitere 480 Takte Flotten-/Ein-LKW-Prüfung. Kein neuer Bestand vor Entladung. Nachgelagerte Fahrten haben Vorrang. Unterbrochene beziehungsweise unerschlossene Zufahrten erfinden keine Strecke; ein vom Spieler gebauter Anschluss macht das entfernte Grundstück erreichbar.
- Migration ehemaliger Bandladungen: voller Ausgangspuffer, gesondert erhaltener Überlauf, keine Doppelgutschrift bereits angekommener Ware, vollständige Rückgabe beim Auflösen der Linie. Alte Spielstände ohne Stadtdienste erhalten sichere Standardwerte.
- Tatsächliche Gemeindefahrten für Polizei, Feuerwehr, Rettungsdienst und Taxis, begrenzte Dienstflotten, eigene Standorte mit Upgrades, Fahrgast erst nach Abholung und kein Fahrgast nach dem Absetzen. Einnahmen erst nach Hilfe beziehungsweise Fahrtabschluss; einmalige Abholung der Stadtkasse. Neue Fahrten ausschalten lässt bestehende Wege sauber enden.
- JSON-Speichern während laufender Dienste und anschließende Simulation liefern dieselben verschachtelten Zahlen und Zustände wie der fortgesetzte ursprüngliche Lauf. Ganzzahl-/Fließkomma-Darstellung wird numerisch verglichen, Toleranz 1e-8. Die Wanduhr `last_seen` wird beim Vergleich ausgeschlossen. Gespeicherte Standort-Referenzen schützen auch nach dem JSON-Roundtrip korrekt die aktive Fahrt. Ein versetztes Wohnhaus beendet seinen Spaziergang ohne Gutschrift; laufende Fahrzeugziele bleiben geschützt. Straßen können unter aktiven Fahrten nicht entfernt werden.
- Tatsächlich durch den Viewport geleitete ScreenTouch-/ScreenDrag-Ereignisse über Katalogkarten: Scrollweg, kein versehentlicher Bau-/Kaufauftrag, unbewegte Weltkamera, funktionierender kurzer Tipp und abgebrochene OS-Touchgeste. Die Scrollleiste ist nicht erforderlich. Keine reinen Aufrufe von Button-Callbacks als Ersatz für die Gestenprüfung.
- Desktop OpenGL: 23 UI-, 9 Landschafts-, 22 Liefer-/Baustellen- und 27 neue Verkehrsprüfungen, zusammen **81**. Echte gerenderte Dienstfahrzeuge, sechs Bewohnerwege, tatsächliche geladene Tiefbett-Auflieger, Taxi-Einstieg und sich bewegende Ladungen. Zusätzliche synthetisch eingespeiste ScreenTouch-/ScreenDrag-Ereignisse über `Input.parse_input_event` bei 540×960 und 360×640, einschließlich der Bildschirm-/Viewport-Skalierung. Das prüft den Eingabepfad der Engine mit Bildschirmkoordinaten, keine physische Touch-Hardware.
- Vier neue Vorschauen aus einem ausdrücklich aufgebauten Demonstrationsprofil: Stadtverkehr, Fracht, Dienste und gewischter Baukatalog. Vorhandene Nutzerprofile wurden nicht für Tests oder Aufnahmen verwendet.
- Keine Behauptung einer vollständigen Kollisions-/Ampelsimulation oder einer neuen End-to-End-Logistik für sämtliche alten fortgeschrittenen Fabriken. Die offenen Master-Phasen bleiben in [Industrie-Masterplan](INDUSTRY-ROADMAP.md) dokumentiert. Kein Android-Geräte-, Touch- oder Leistungsnachweis für die neue Version.

## Auslieferung 0.16

- APK-Quellstand: `c8c9e032f643d965e432773af4b6d334c62d3ed1`.
- APK: 58,257,975 Bytes, SHA256 `64253ea0dd1eaeee5f2e4e9cdb2105a86e36c2999a219b1a527319caaaafcab4`.
- Quell-ZIP: 177 Dateien, 8,892,181 Bytes, SHA256 `f17dc81dcbaff01bfd59c3a656e7d9dd6bd5a2b5e69ea9225f8346cd1391a081`. Jede Datei gegen den Git-Blob des APK-Quellstands geprüft; Release-Dateien sind aus dem Quellarchiv ausgeschlossen.
- Gleiches Zertifikat wie 0.15: `08b5b5b8d6edb6590545fe77f6f14248f6f14256c9edc781989ac41100ff1005`. Versionscode 1600, Speicherformat 1, API 24+, ARM64/ARMv7, v2-Signatur, 16-KB-ZIP-Ausrichtung, Hochformat, GL Compatibility und keine Berechtigungen geprüft. Alle neuen Laufzeitskripte sind im APK enthalten; das entfernte Conveyor-Skript sowie Tests, Build-Helfer und Release-Dateien sind ausgeschlossen.

- Frische unabhängige GitHub-Kopie unter `/workspace/timber-restore-16`: Erstimport, alle **12.461 Headless-Prüfungen**, erster-Haus-Verlauf, Hauptszenenstart sowie alle **81 OpenGL-Prüfungen** erneut bestanden. Die Kopie hat einen sauberen Git-Status.
- APK, passende Quell-ZIP und alle vier neuen Vorschauen vom festen Tag `v0.16.0-traffic` vollständig per HTTPS mit HTTP 200 heruntergeladen. Alle SHA256 und Dateigrößen stimmen mit den Originalen und der unabhängigen GitHub-Kopie überein. Bericht: [download-verification-16.json](download-verification-16.json).

## Historischer Prüfbericht 0.15

# Prüfung 0.15 — Lieferwerk, erster Abschnitt des Industrie-Masterplans

- Lokaler vollständiger Lauf von `bash scripts/test.sh`: 225 Regel-, 4.092 Szenen-, 56 Platzierungs-, 42 Werkstatt-, 23 Begleiter-, 30 Alltagsszenen-, 216 Stadt-, 177 Landschafts-, 3.457 Lieferketten- und 56 Baustellenprüfungen: **8.374 Headless-Prüfungen** ohne Fehler. Zusätzlich erster-Haus-Verlauf ohne Geld-/Materialgeschenke nach 1.682 simulierten Sekunden und Hauptszenenstart.
- Lieferkette: lokale Ein-/Ausgangspuffer, reale Fahrzeiten, Holzäquivalent-Erhaltung über 260 Takte, ankommende Kapazitätsreservierung, produktionsabhängige Bandladungen, Möbelverkauf erst nach Ankunft, pünktlicher Bonus, 70-%-Spätpreis, Pause und Rückgabe der Vorräte beim Auflösen. Laufende Zuordnungen schützen Gebäude vor Standortänderungen.
- Baustellen: Geld-Upgrades vor Level 4, Migration vorhandener Firmen, sieben Phasen mit exakt aufgeteiltem Gesamtbedarf, Warten auf Material, reale Teilladungen und Straßenpunkte, begrenzter gemeinsam verwendeter Fuhrpark, fehlende spätere Hardware, exakte Depotkäufe, Pausieren, gemeinsame Crew-Zuweisung, Priority-Dispatch, zwei parallele Projekte, unerreichbarer Zielpunkt, sicherer Abbruch einschließlich Ladung und Ablehnung bei vollem Rückgabelager.
- Echter atomarer Save-/Load-Weg während einer Baustellenfahrt und Fortsetzung aller Arbeits-/Transportdaten. JSON-Zahlen werden als Zahlen verglichen; Fließkommatoleranz 1e-8, alle Struktur-/Mengenbedingungen bleiben erhalten. Ein dabei entdeckter Fehler durch JSON-Schlüsselreihenfolge wurde durch eine feste Dispatch-Reihenfolge beseitigt. Schreibende JSON-Ausgabe verwendet volle Fließkommagenauigkeit.
- Neue Szene prüft tatsächliche Materialanzeigen, deren Antippen, lokale Maschinen, Möbel-LKW-Ladung und sieben Bauteile. Bauarbeiter warten ohne Phantommaterial, tragen erst nach gültiger Lieferung und wechseln zum Werkzeugzustand. Frühe und alte Baustellen bleiben mit der bisherigen Fertigstellung kompatibel.
- Desktop OpenGL: 23 UI-, 9 Landschafts- und 22 Liefer-/Baustellenprüfungen, insgesamt **54** ohne Fehler. Enthalten sind tatsächlich gerenderte Materialicons, freie HUD-Bereiche, Ladung auf Hin-/Rückfahrt, reale teilweise belieferte Baustelle und kleine Portraitfenster mit skalierter UI.
- Vier Vorschauen aus einem ausdrücklich aufgebauten Demonstrationsprofil; keine Nutzerprofile werden dafür verwendet. Sie zeigen Lieferwelt, Materialbaustelle und deren Menüs. Kein echter Android-Geräte- oder Leistungsnachweis. Offene Master-Phasen: [Industrie-Masterplan](INDUSTRY-ROADMAP.md).

## Auslieferung 0.15

- APK-Quellstand: `7ca882361dc542394440f2b911725d8e4e78128f`.
- APK: 58.240.874 Bytes, SHA256 `cc18ae1e7ae29061beeff725b4ad74cd5e504a98e90ea79011ad111e58246c1a`.
- Quell-ZIP: 160 Dateien, 7.868.511 Bytes, SHA256 `a713e233e6d6f53670ed357c2f63b20f516f861bb9ccf498c69dcabfcd544cb2`. Jede Datei gegen den Git-Blob des APK-Quellstands geprüft.
- Gleiches Zertifikat wie 0.14: `08b5b5b8d6edb6590545fe77f6f14248f6f14256c9edc781989ac41100ff1005`. Versionscode 1500, Speicherformat 1, API 24+, ARM64/ARMv7, v2-Signatur, 16-KB-ZIP-Ausrichtung, Hochformat, GL Compatibility und keine Berechtigungen geprüft. Alle neuen Laufzeitskripte liegen im APK; Tests, Build-Helfer und Release-Dateien sind ausgeschlossen.
- Frische unabhängige GitHub-Kopie unter `/workspace/timber-restore-15`: Erstimport, vollständige 8.374 Headless-Prüfungen, erster-Haus-Verlauf und Hauptszenenstart bestanden. Anschließend auch alle 54 OpenGL-Prüfungen in dieser unabhängigen Kopie bestanden.

- APK, passende Quell-ZIP und vier Vorschauen vom festen Tag `v0.15.0-delivery` vollständig per HTTPS mit HTTP 200 heruntergeladen. Alle Bytezahlen und SHA256 stimmen mit Originaldateien und der unabhängigen GitHub-Wiederherstellung überein. Bericht: `download-verification-15.json`.

## Historischer Prüfbericht 0.14

# Prüfung 0.14 — Ein lebendiges Waldtal

- 220 Regel-, 4.092 Szenen-, 56 Platzierungs-, 42 Werkstatt-, 23 Begleiter-, 30 Alltagsszenen-, 216 Stadt- und 177 Landschaftsprüfungen: 4.856 Headless-Prüfungen. Weiterhin frischer erster-Haus-Verlauf nach 1.682 simulierten Sekunden und abschließender Hauptszenenstart. Die Szenenanzahl berücksichtigt die Positionen der neu verteilten 1.000 Bäume; die bisherigen Bedingungen wurden nicht entfernt.
- Neue Landschaftsprüfung: tatsächlich gerendertes Gelände/Wasser, unveränderte Wirtschaft, flache alte und neue Bauflächen, Hügel, ausgesparter Bach und See, kontinuierliche Biomfarben, begrenzter fester Dekorationspool, freier Standort in einer Wiese, Vegetationsräumung beim echten Verschieben und Straßenbau, unveränderte Gebäudepositionen und eigener Akkumodus. Dekoration ersetzt keine nutzbaren Bäume.
- 23 bestehende OpenGL-Prüfungen plus neun neue Grafikprüfungen: Farbverarbeitung, ein separat gerenderter echter instanzierter Laubbaum mit grüner statt schwarzer Krone, tatsächlicher Instanzpuffer vor/nach Verschieben, sichtbare Wasserpixel im Bach sowie gültiger Vordergrund bei weitem Zoom.
- Der Kamerafehler wird bei 650 Einheiten Zoom mit 540×960 und 540×1170 geprüft: Auch die untere sichtbare Spielfläche liegt vor der Kamera und trifft den Boden. Das frühere flache Leerfeld unter der abgeschnittenen Landschaft wird damit gezielt abgedeckt.
- OpenGL-Aufnahmen aus ausdrücklich aufgebautem Demonstrationsprofil: frischer Einstieg, Gesamtansicht, Industrie, Bach/Brücke und 19-Uhr-Nebel bei der alten weiten Zoomstufe. Spielstände des Nutzers werden nicht für Aufnahmen verwendet.
- Wirtschaft, gespeicherte Gebäude und eigenes Straßennetz bleiben erhalten; feste Schotterzufahrten sind befahrbar. Bach, Picknickplatz und Aussichtsturm sind Landschaftselemente ohne neue Erträge oder Fahrlinien. Reale Android-Installation/Touch, Akku, Temperatur und Leistung dieser Version bleiben auf Hardware zu prüfen.

## Auslieferung 0.14

- APK-Quellstand: `8fdd1a6bd54cbfffe312b018c1785aa12293ddda`.
- APK: 58.181.415 Bytes, SHA256 `0634691f9fe0357572a417a5031dcfbeee2b87585eb252f0040fc43976f4fbb7`.
- Quell-ZIP: 126 Dateien, 6.847.459 Bytes, SHA256 `77fbc20fe249a91c4f7c0246baad6067d86a6ad3f8c1d5d51008ad5b8bbe7256`. Jede Datei einzeln gegen den Git-Blob des APK-Quellstands geprüft.
- Zertifikat SHA256: `08b5b5b8d6edb6590545fe77f6f14248f6f14256c9edc781989ac41100ff1005`, identisch zu 0.13. Versionscode 1400, Speicherformat 1, v2-Signatur und 16-KB-ZIP-Ausrichtung geprüft; GL Compatibility, keine Berechtigungen. `ValleyLandscape` im APK enthalten; Tests und Release-Dateien ausgeschlossen.
- Frische unabhängige GitHub-Kopie: `/workspace/timber-restore-14`. Erstimport, 4.856 Headless-Prüfungen, erster-Haus-Verlauf und Hauptszenenstart dort erneut bestanden. Anschließend auch alle 32 OpenGL-Prüfungen in dieser Kopie bestanden.

- APK, passende Quell-ZIP und drei Landschaftsvorschauen vom festen Tag `v0.14.0-valley` vollständig per HTTPS mit HTTP 200 heruntergeladen. Alle SHA256 stimmen mit Originaldateien und der frischen GitHub-Wiederherstellung überein. Bericht: `download-verification-14.json`.

## Historischer Prüfbericht 0.13

# Prüfung 0.13 — Die erste Kleinstadt

- 220 Regel-, 4.139 Szenen-, 56 Platzierungs-, 42 Werkstatt-, 23 Begleiter-, 30 Alltagsszenen- und 216 neue Stadtprüfungen: 4.726 Headless-Prüfungen. Dazu frischer erster-Haus-Verlauf nach 1.682 simulierten Sekunden und Hauptszenenstart.
- Mietprüfungen: manuelle Konten, exakte Auszahlung, keine Doppelabholung, acht Stunden Offline-Miete, JSON-Roundtrip, einmalig bezahlte Hausverwaltung und kostenlose Beibehaltung automatischer Miete für alte Profile.
- Bauprüfungen: Voraussetzungen und Preis vor Erschließung, 24/36 verfügbare Grundstücke, tatsächlich fertig gebautes Haus im Ostviertel, Straßenanschluss, Meterpreis nur für neue Strecke, Abbruch ohne Kosten, Ablehnung bei Wasser, gesperrtem Viertel, Gebäuden oder fehlendem Anschluss. Asphalt und unabhängige Fußwege bleiben unterscheidbar.
- Verkehr: physisch freie Haltestellen, keine Busse auf Fußwegen, eindeutige Stationen, Einwohner-Voraussetzung, echte Graphverbindung, Bewegung und vier Sekunden Aufenthalt, Fahrgeld erst bei abgeschlossener Rundfahrt, JSON-/Offline-Fortschritt, Schutz von Haltestellen und Zwischenverbindungen gegen Abriss. Beschädigte/unverbundene gespeicherte Routen verdienen kein Geld.
- Szenenprüfungen: Werkzeug- und Transportstufen wechseln die sichtbaren Modelle, begrenzte Forstmaschinenzahl, bewegter Sägearm bei tatsächlichem Erntefluss, alle zwölf Gebäudemodelle samt Details innerhalb ihrer Grundstücksfläche, direkter Straßen-/Buszugang, echte Bestätigung aus der Weltvorschau, sichtbarer fahrender Linienbus, Antippen des Mietlabels und Förderverbindung für einen verschobenen Betrieb im Ostviertel.
- Zusätzliche 23 echte OpenGL-Prüfungen für 3D-Menüs, Portrait, Transparenz, Beleuchtung und Resume. Stadt, Maschinen, neue Bauflächen, Straßen-Vorschau und Busmenü werden aus einem ausdrücklich aufgebauten Demonstrationsprofil gerendert. Nutzerprofile werden dafür nicht verwendet.
- Begrenzungen: vereinfachte Nachfrage je Linie und gemeinsame Produktionspuffer; keine vollständige Kollisions-/Stausimulation und keine individuellen Exportfahrten. Echte Android-Updateinstallation, Touch/Safe Area, Ton, Temperatur und Akku bleiben für 0.13 auf Hardware zu prüfen. Der Nutzer hat zuvor 0.11 auf seinem Telefon als funktionierend bestätigt.

## Auslieferung 0.13

- APK-Quellstand: `7bc708e2e5d2e37865570c3d6007bf8c883831a4`.
- APK: 58.164.761 Bytes, SHA256 `8d293e89aa975fe5b49e8313a8a57b0210edc0a49aa3f77e8df90b5399be3225`.
- Quell-ZIP: 112 Dateien, 4.697.731 Bytes, SHA256 `8933dc51e059bd43120dcabec36e2b1ff5ecfd660c37cbf6ffcffc0d278f428d`. Jede Datei stimmt mit ihrem Git-Blob des APK-Quellstands überein.
- Zertifikat SHA256: `08b5b5b8d6edb6590545fe77f6f14248f6f14256c9edc781989ac41100ff1005`, unverändert zu 0.12. Versionscode 1300, Speicherformat 1, v2-Signatur und 16-KB-ZIP-Ausrichtung geprüft; GL Compatibility, keine Berechtigungen. Neue Stadt-, Straßen-, Bus- und Forstmaschinen-Skripte sind im Paket enthalten; Tests und Release-Dateien sind ausgeschlossen.
- Frische unabhängige GitHub-Kopie: `/workspace/timber-restore-13`. Erstimport, vollständige Headless-Suite, erster-Haus-Verlauf und Hauptszenenstart dort erneut bestanden. Anschließend auch die 23 OpenGL-Prüfungen in dieser Kopie bestanden.

- APK, passende Quell-ZIP, Stadt- und Busvorschau vom festen Tag `v0.13.0-town` vollständig per HTTPS mit HTTP 200 zurückgeladen. SHA256 stimmen mit Originaldateien und der unabhängigen GitHub-Wiederherstellung überein. Bericht: `download-verification-13.json`.

## Historischer Prüfbericht 0.12

# Prüfung 0.12 — Waldleben

- 220 Regel-, 4.135 Szenen-, 56 Platzierungs-, 42 Werkstatt-, 23 Begleiter- und 30 neue Alltagsszenenprüfungen: 4.506 Headless-Prüfungen plus frischer erster-Haus-Verlauf und abschließender Start. Die unveränderte Wirtschaft erreicht das erste Haus weiterhin nach 1.682 simulierten Sekunden.
- Neue Prüfungen: kompatible alte Profile; keine Feier für Bestandsgebäude oder bloße Bauaufträge; Pausengast ohne zusätzliches Personal; Sitzpose/Tasse und Rückkehr; vollständiger Laufweg innerhalb des ursprünglichen und verschobenen/gedrehten Grundstücks; gegenseitige Begrüßung mit Abklingzeit; Schalter/Restore/Prestige; echte bezahlte Fertigstellung am gewählten Standort; begrenzte Zuschauer und fester Partikelpool; unveränderte Ressourcenrechnung; Akkumodus; Vorgartenspaziergang am tatsächlichen gedrehten Haus.
- Die bisherigen 23 echten OpenGL-Prüfungen für UI und Benno bestehen weiterhin. Bildausgabe von Hüttenvorplatz mit Pausengast und einer tatsächlich im Capture-Profil fertig gebauten Hütte geprüft. Beschriftung höher gesetzt, um Gebäudenamen nicht zu überdecken.
- Alle Capture-Bilder verwenden einen ausdrücklich aufgebauten Demonstrationsstand. Das Einfrieren des Pausengasts für das Foto verändert keine Nutzerdaten. Die Eröffnungsaufnahme verwendet einen bezahlten Bauauftrag und dessen echte Fertigstellung im Demonstrationsprofil.
- Der Nutzer hat Version 0.11 als auf seinem Handy funktionierend bestätigt. Für 0.12 sind reale Geräte-, Sound-, Temperatur- und längere Häufigkeitstests noch offen. Klang wird im Grafiktest mit Dummy-Audiotreiber erzeugt; hier wurden keine Lautsprecher geprüft.
- Straßennetze, Baukosten und Wirtschaft bleiben unverändert. Alltagsszenen sind kosmetisch, keine neue Schicht für Arbeitszeiten oder Fußgänger-Kollisionen. Park-/Hüttenausstattung ist Teil ihrer bestehenden Grundstücksfläche.

## Auslieferung 0.12

- APK-Quellstand: `6f083f473916141bcd5ae917641e463284a62c43`.
- APK: 58.114.729 Bytes, SHA256 `d52e3c4f4d9a50a20bf843d2d2ae721fc2ade62f3292c571ed899ad4763cc9a0`.
- Quell-ZIP: 91 Dateien, 3.148.768 Bytes, SHA256 `ef04674ddaa0e75e21ff65cc291c04e1f045d0ff730116108e46dbbe3211f30c`. Alle enthaltenen Dateien stimmen mit den Git-Blobs des APK-Quellstands überein.
- Zertifikat SHA256: `08b5b5b8d6edb6590545fe77f6f14248f6f14256c9edc781989ac41100ff1005`, unverändert zu 0.11. Versionscode 1200, Speicherformat 1, v2-Signatur und 16-KB-ZIP-Ausrichtung geprüft; GL Compatibility, keine Berechtigungen.
- Neue unabhängige GitHub-Kopie: `/workspace/timber-restore-12`. Vollständige Headless-Suite nach Erstimport sowie anschließende OpenGL-Prüfung dort erneut bestanden. APK, passende Quell-ZIP und beide Vorschauen vom festen Tag `v0.12.0-cozy` vollständig per HTTPS mit HTTP 200 zurückgeladen. Alle SHA256 stimmen mit Originaldateien und GitHub-Wiederherstellung überein. Bericht: `download-verification-12.json`.

## Historischer Prüfbericht 0.11

# Prüfung 0.11 — Benno im Wald

- 220 Regel-, 4.135 Szenen-, 56 Platzierungs-, 42 Werkstatt- und 23 neue Begleiterprüfungen: zusammen 4.476 Headless-Prüfungen. Weiterhin frischer erster-Haus-Verlauf nach 1.682 simulierten Sekunden sowie abschließender Szenenstart.
- Begleiterprüfungen: kompatibles altes Profil, Begrüßung ohne Währungsänderung, Winkeauslöser, wegklickbare Blase, keine angebliche Fertigstellung bei bloßem Bauauftrag, Reaktion auf Fertigstellung, Menüs und Platzierung frei, Hinweise aus echtem Vorrat, Abschalten ohne Ereignisstau, Einstellung nach Restore/Prestige, erneutes Einschalten, nur einmaliger gleicher Tipp, tatsächlicher Offline-Bericht nur einmal und Rückkehrbegrüßung und korrekter Baum-Missionsschwelle nach Prestige.
- 23 OpenGL-Prüfungen: bisherige 3D-Menüs plus getrennte Portraitbeleuchtung, wirklich gerenderter transparenter Biber, sichtbare Silhouette und Änderung der gerenderten Pixel beim Winken.
- Begrüßung und Biber, Werkstatt, Baukatalog, Platzierung und neue Willkommen-Grafik unter OpenGL geprüft. Die fortgeschrittenen Capture-Bilder verwenden einen ausdrücklich aufgebauten Demonstrationsstand und eine inszenierte Feierblase; ihre Ressourcen sind kein Nutzerspielstand.
- APK-Gerätetest, Benachrichtigungen/Resume unter Android und langfristige Begleiterhäufigkeit bleiben auf Hardware zu prüfen. Kein Sprachsynthese-/Voiceover-System, keine Loginpflicht, keine täglichen Verluststrafen oder erzwungenen Belohnungsdialoge.

## Auslieferung 0.11

- APK-Quellstand: `66aab5d885a18d5446b4450fa6c9fc05724a7c5e`.
- APK: 58.102.026 Bytes, SHA256 `3588bc86c9f0364438e171aaed11e3dd8b9223bfe90c8d1add7a954c11b2997a`.
- Quell-ZIP: 82 Dateien, 2.580.510 Bytes, SHA256 `6f6e72f015b2900f377f049195421f1ac2a615530569beab3f786112a9039d0d`. Dateiinhalte einzeln gegen ihre Git-Blobs des APK-Quellstands geprüft.
- Zertifikat SHA256: `08b5b5b8d6edb6590545fe77f6f14248f6f14256c9edc781989ac41100ff1005`, identisch zur bisherigen APK. Versionscode 1100, Schema 1, unveränderte Paketkennung und Speicherdatei, v2-Signatur und 16-KB-ZIP-Ausrichtung geprüft.
- Neue unabhängige GitHub-Kopie unter `/workspace/timber-restore-11`. Erstimport, vollständige Headless-Suite und anschließend separate OpenGL-Prüfung. Alle 4.476 Headless-Prüfungen, der erste-Haus-Verlauf, Hauptszenenstart und die 23 OpenGL-Prüfungen bestehen auch dort. APK, Quell-ZIP und Benno-Vorschau vom unveränderlichen Tag `v0.11.0-benno` vollständig per HTTPS mit HTTP 200 zurückgeladen; alle SHA256 stimmen mit den Originaldateien sowie den Dateien aus der GitHub-Wiederherstellung überein. Bericht: `download-verification-11.json`.

## Historischer Prüfbericht 0.10

# Prüfung 0.10 — Sculpted World

- 220 Regel-, 4.135 Szenen-/Geometrie- und 56 Platzierungsprüfungen. Der frische Spielverlauf erreicht das erste Haus weiterhin nach 1.682 simulierten Sekunden ohne zusätzliche Ressourcen.
- 42 Werkstattprüfungen einschließlich Schatten an/aus durch Standard-/Akkumodus. Zusammen 4.453 Headless-Prüfungen plus Progressionslauf und abschließender Hauptszenenstart.
- Separate echte OpenGL-Prüfung: sieben gerenderte 3D-Symbole jeweils auf sichtbare Silhouette, transparente Ränder und farbige beleuchtete Details geprüft. Die 3D-Szene der Symbole ist von der Welt getrennt. Druckzustand ändert das Flächenbild und Inhaltsabstand. Nach Anwendungsfortsetzung wird neu gerendert. 19 Prüfungen.
- OpenGL-Aufnahmen von Einstieg, offener Werkstatt, Baukatalog, Bauvorschau, Einführung und aufgebauter Stadt. Der fortgeschrittene Stand ist eine explizite Capture-Demonstration; kein Benutzerspielstand wird dafür verändert.
- Kein Größenlimit von 55 MB: Symbole, Oberflächen und Modelle werden ressourcenschonend aus eigener Geometrie und Vektoren erzeugt. Die Paketgröße allein ist kein Maß für Grafikqualität.
- Schattenleistung, Temperatur, Safe Area und Wiederaufnahme auf realen Android-Geräten sind weiterhin separat zu prüfen. Der Akkumodus stellt einen Ausweichmodus ohne neue Weltschatten bereit. Die Prüfungen hier sind keine Messung auf einem Telefon.

## Auslieferung 0.10

- APK-Quellstand: `54a6e86abaea53ac6a829e7a6c6598129320bc71`.
- APK: 56.585.744 Bytes, SHA256 `b44b4a8bfbd83339407d06e3a2c4b9cf246f069bf6fea96a678a6adb91150e2d`.
- Quell-ZIP: 69 Dateien, 1.947.082 Bytes, SHA256 `305f51e32f7f83226989e1c3d8466752a9c2b87b53f5d0aa99fb764d94aec796`. Jede enthaltene Datei stimmt mit ihrem Git-Blob am APK-Quellstand überein.
- Zertifikat SHA256: `08b5b5b8d6edb6590545fe77f6f14248f6f14256c9edc781989ac41100ff1005`, unverändert zu 0.9. Versionscode 1000, Spielstandschema 1, GL Compatibility, keine Berechtigungen.
- Wiederherstellung: neue unabhängige Kopie von GitHub unter `/workspace/timber-restore-10`. Zuerst Import mit `bash scripts/godot.sh --headless --editor --import --quit`, dann `bash scripts/test.sh`. Die gesonderte OpenGL-Prüfung ist `Tests/VisualUI.gd` und benötigt einen verfügbaren X11-/OpenGL-Bildschirm. Grafikprüfung nach dem Import ausführen; ein direkter Skriptstart vor dem Erstimport hat noch keinen globalen GDScript-Klassenindex.
- APK, passende Quell-ZIP und Vorschau vom festen Tag `v0.10.0-sculpt` vollständig per HTTPS zurückgeladen, jeweils HTTP 200 und identischer SHA256. Bericht: `download-verification-10.json`. In der neu geklonten Kopie bestehen nach dem Erstimport sämtliche 4.453 Headless-Prüfungen, der erste-Haus-Verlauf, Hauptszenenstart sowie die 19 OpenGL-Prüfungen erneut.

## Historischer Prüfbericht 0.9

# Prüfung 0.9 — Open Workshop

- Bestehende 220 Regel-, 4.135 Szenen-/Geometrie- und 56 Platzierungs-/Einführungsprüfungen unverändert im Umfang bestanden. Der frische Verlauf erreicht das erste Haus weiter nach 1.682 simulierten Sekunden ohne Zusatzressourcen.
- 40 zusätzliche Werkstattprüfungen: tatsächlich leere Maschine steht; echte Umwandlung treibt das Sägeblatt an; sofortige Pause friert Werkzeug und Werkstück ein; Materialmangel stoppt; ein Bediener arbeitet passend zur Maschine; alle acht Produktionsarten werden auf Stufen 1/10/100 instanziiert, ohne Ressourcen zu ändern; HUD bleibt bei drei Bildschirmgrößen innerhalb der Zeichenfläche.
- OpenGL-Bildausgabe unter Mesa/Xvfb: neuer Einstieg, offene Säge, Stadtansicht, Baukatalog, Platzierung und Willkommen aufgenommen. Die ausgebaute Welt und Materialvorräte sind ausschließlich ein Demonstrationsprofil des Capture-Skripts; kein bestehender Nutzerspielstand wird dafür geändert.
- Schema 1, Speicherdatei und Paketkennung unverändert. Paket/Versionscode 900, v2-Signatur und 16-KB-ZIP-Ausrichtung geprüft; Zertifikat stimmt mit 0.8 überein. Aus GitHub neu nach `/workspace/timber-restore-09` geklont; alle 4.451 Prüfungen, der frische Verlauf und der Hauptszenenstart erneut bestanden. Reale Geräteinstallation, Touch und mobile Leistung dieser Version sind noch nicht geprüft.
- Die Referenzbilder dienen als Richtung für offene Produktionsflächen und übersichtliche Bedienung. Modelle und Symbole sind eigene Geometrie/Vektoren. Es werden keine Screenshots oder Spielressourcen fremder Spiele in die App eingebunden.

## Auslieferungsstand 0.9

- Quell-Commit: `8a9f0eb7f1486d1d5b1f24616f057d718c3e62be`.
- APK: 56.577.150 Bytes, SHA256 `9ec4fe4252eb8914b908a50f0fa935b181a1e693f0def026e8f9420e379a15c1`.
- Quell-ZIP: 62 Dateien, 1.569.317 Bytes, SHA256 `6bc0400009cd0a514d63d338275179f5ccebc7cf52701264482c0b3bfec5fc4f`. Jede Datei gegen Git-Blob des APK-Quellstands geprüft.
- Zertifikat SHA256: `08b5b5b8d6edb6590545fe77f6f14248f6f14256c9edc781989ac41100ff1005` (unverändert).
- Beide externen HTTPS-Downloads vom unveränderlichen Tag `v0.9.0-workshop` vollständig mit HTTP 200 zurückgeladen und SHA256 mit den Originaldateien verglichen. Auch die APK und ZIP aus der unabhängigen GitHub-Kopie stimmen überein. Bericht: `download-verification-09.json`.

## Historischer Prüfbericht 0.8

# Prüfung 0.8 — Living Industry

- 220 Regelprüfungen: zusätzlich volles Sägespäne-Lager, korrekte Überlaufmenge, optionaler Verkauf, Weiterverarbeitung und Wiederanlauf einer gespeicherten Firma mit 2.500 Holz/Sägespänen. Restore kopiert Daten unabhängig, ohne den geladenen Ausgangsstand zu verändern.
- 56 Platzierungs-/Einführungsprüfungen: Straßen/Wasser/Überlappung, kostenlose abgebrochene Vorschau, bezahlte Baustelle, gesperrte doppelte Platzierung, Rotation und gespeicherter Standort, kostenloses Verschieben samt Erhalt von Stufe/Geld, frei positionierte Häuser, altes Profil ohne Zwangstutorial, neue Einführung, Spänebox und Förderverbindungen mit Straßendurchfahrt.
- Weiterhin 4.135 Szenen-/Geometrieprüfungen, frischer Verlauf bis zum ersten Haus und abschließender Hauptszenenstart.
- OpenGL-Bilder von frischer Welt, Baukatalog, Platzierungsvorschau, Willkommen und ausgebautem Demonstrationsstand geprüft.
- Android-Updateprüfung: neue Versionsnummer 800, unveränderte Paketkennung und bisheriger Testsignaturschlüssel. Paket- und Downloadprüfung werden beim finalen Export erneut ausgeführt.
- Finaler APK-Export bestanden: 56.560.291 Bytes, SHA256 `37c679d49c73a17f3d4672b9e4328060e47034bc9a9e86f58db01bdb967fffb1`, Quell-Commit `dfcaff6d05191fdd12b949b8eeec792eb6b24cc1`. Signatur stimmt mit der gespeicherten 0.7-APK überein; keine Android-Berechtigungen, ARM64/ARMv7, OpenGL, Hochformat und 16-KB-ZIP-Ausrichtung geprüft.
- Grenzen: echte Touch-/Installations-/Leistungsprüfung auf einem Telefon bleibt offen. Förderstrecken zeigen aktive Produktion und gemeinsame Materialpuffer; es gibt keine zusätzliche Fahrzeugkollision oder diskrete Simulation jedes einzelnen Bretts.

Wiederherstellung 0.8: Der frische GitHub-Klon `/workspace/timber-restore-08` wurde bis zum Quell-Commit `dfcaff6d05191fdd12b949b8eeec792eb6b24cc1` aktualisiert. Darin bestanden alle 220 Regel-, 4.135 Szenen-/Geometrie- und 56 Platzierungs-/Einführungsprüfungen, der frische Spielpfad und der Hauptszenenstart erneut.

Der folgende Bericht dokumentiert den ursprünglichen 0.7-Meilenstein; seine Hashwerte beziehen sich auf diese ältere Fassung.

# Prüfbericht zum Wiederaufbau

Stand: 19. Oktober 2026. Godot 4.6.3, GDScript; Version 0.7.0-test.

## Automatisierte Prüfungen

- **207 Regelprüfungen, keine Fehler:** Rucksack und Lagergrenzen; echte Ein-/Ausgänge der Verarbeitung; atomare Bezahlung; laufender Bau und Upgrades; doppelte Aufträge; Miete; Forschung; 100 Loot-Ziehungen; Boosterablauf; einmalige Missions-/Auftragsprämien; identische Vordergrund-/Offline-Simulation; Prestige und steigende Kosten; Crafting; Ausrüsten; permanente Loot-Upgrades; Regionen; Materialreservierung und automatische Einzelbestellung; drei Projektstufen; faire Materialzuteilung unabhängig von Betriebsreihenfolge; Save/Load und beschädigtes Hauptsave mit Backup-Fallback.
- **Frischer Spielverlauf:** Das erste Haus wird ohne Geld-/Materialgeschenke nach 1.682 simulierten Sekunden fertig. Danach erwirtschaftet es Ertrag. Startbedingungen sind dieselben wie im Spiel. Die Teststeuerung verwendet normale Aktionen, Aufträge und Verkäufe.
- **4.135 Szenen-/Geometrieprüfungen, keine Fehler:** Zehn Waldgruppen mit zusammen 1.000 Bäumen; Bäume auf Land und abseits der Straßen/Zufahrten; mobile Menüs und Grundstücksauswahl; aktiver Materialplaner; sofort sichtbare bezahlte Baustelle und Entfernung des Gerüsts nach Abschluss; Baumabbau; Welt-/Heimkamera und kleines Fenster.
- **Hauptszene:** Abschließender Headless-Start ohne GDScript-/Laufzeitfehler.
- **Echte Bildausgabe:** OpenGL-Start unter Xvfb und Mesa llvmpipe; frische Welt, ausgebauter Demonstrationsstand und Industrie-Menü aufgenommen und visuell geprüft. Dabei gefundener Kopfbereich-Umbruch korrigiert. Desktop-Audio im Capture-Lauf auf Dummy gesetzt; die selbst erzeugten Audio-Wellen sind implementiert, Lautsprecher wurden hier nicht geprüft.

## Android

Signierter Debug-Export für ARM64/ARMv7. APK-Integrität, Signatur, 16-KB-ZIP-Ausrichtung, Android 7.0+, Hochformat, OpenGL und keine angeforderten Berechtigungen werden im Build-Skript geprüft. Der endgültige Hash steht bei der APK im Paketbericht. Kein echter Handy-/Emulator-Starttest.

## Sicherung

Git-Meilensteine werden zum Repository übertragen. Abschließend wird aus GitHub in ein neues Verzeichnis geklont, der gespeicherte Stand geprüft und die APK mit dem lokalen SHA256 verglichen. Quell-ZIP und vollständiges Git-Bundle mit SHA256-Manifest ergänzen die externe Git-Sicherung. Ein nicht bestätigter Push gilt nicht als Sicherung.

Ergebnis der Wiederherstellungsprüfung: GitHub-Commit `6d4d65f65cc9d35ff635ec25a42084b29c53449b` wurde erfolgreich nach `/workspace/timber-restore-check` geklont. Dort bestand die vollständige Testsuite erneut (207 Regeln, frischer Verlauf, 4.135 Szenen-/Geometrieprüfungen, abschließender Start). Die zurückgeladene APK stimmt mit SHA256 `893e4ec1ea95a18881d1abf9ee0ac8caf16797699fd1d3bbb908755a4788041e` überein.

Beide direkten HTTPS-Downloads von `raw.githubusercontent.com` wurden vollständig abgerufen: APK HTTP 200, 56.531.203 Bytes; Quell-ZIP HTTP 200, 763.308 Bytes. Beide SHA256-Werte entsprechen `releases/SHA256SUMS.txt`. Das Quellarchiv enthält 43 Dateien, einschließlich Hauptszene, Regeln, Tests und Build-Helfern, ohne Cache, APK oder privaten Schlüssel.

## Offene Nachweise

Kein 50-Stunden-Spieltest, kein Android-Leistungs-/Akkuprofil, keine abschließende Touch-/Safe-Area-/Hintergrundprüfung, keine iOS-/Store-Freigabe. Die erwähnten 28 Minuten sind simulierte Wirtschaft, kein gemessener menschlicher Spieldurchlauf. Screenshots des ausgebauten Gebiets belegen die Darstellung und keine erspielte Progression.

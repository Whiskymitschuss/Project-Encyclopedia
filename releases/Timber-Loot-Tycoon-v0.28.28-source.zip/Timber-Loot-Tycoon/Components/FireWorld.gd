extends Node3D
# Two incidents maximum; fixed meshes and emitters are created once per incident.
var world: Node3D
var scenes={}
var clock=0.0
var hydrants={}
var protection_signature=[]

func create_incident(roof: float) -> Node3D:
 var node=Node3D.new()
 add_child(node)
 var flames=Node3D.new()
 flames.name="Flames"
 flames.position.y=roof-2.0
 node.add_child(flames)
 for i in 6:
  var mesh=MeshInstance3D.new()
  mesh.mesh=flame_mesh()
  mesh.position=Vector3((i%3-1)*2.0,0,(int(i/3.0)-0.5)*2.4)
  mesh.rotation.y=i*1.7
  mesh.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
  var fire_material=ShaderMaterial.new()
  fire_material.shader=preload("res://Shaders/FireTongue.gdshader")
  fire_material.set_shader_parameter("seed",float(i)*1.7)
  mesh.material_override=fire_material
  flames.add_child(mesh)
 var smoke=Node3D.new()
 smoke.name="Smoke"
 smoke.position.y=roof-3.0
 node.add_child(smoke)
 for i in 5:
  sphere(smoke,2.0,Vector3(sin(i*2.0)*1.3,6+i*1.8,cos(i*2.0)),Color("626e78"))
 var sparks=FeedbackFX.emitter("spark",18)
 sparks.name="Sparks"
 sparks.position.y=roof+2
 node.add_child(sparks)
 var steam=FeedbackFX.emitter("water",18)
 steam.name="WaterMist"
 steam.position.y=roof+1
 node.add_child(steam)
 # One shadowless, tightly bounded light per incident; disabled in battery mode.
 var glow=OmniLight3D.new()
 glow.name="FireGlow"
 glow.position.y=roof
 glow.light_color=Color("ff9d4d")
 glow.omni_range=16
 glow.shadow_enabled=false
 node.add_child(glow)
 var meters=Node3D.new()
 meters.name="Meters"
 meters.position.y=roof+10
 meters.set_meta("roof",roof)
 node.add_child(meters)
 for row_id in 2:
  Models.box(meters,Vector3(8,0.45,0.3),Vector3(0,-row_id*0.85,0),Color("273e42"))
  var fill=Models.box(meters,Vector3(7.7,0.28,0.34),Vector3(0,-row_id*0.85,0),Color("f6a35d") if row_id==0 else Color("94dcd8"))
  fill.name="Intensity" if row_id==0 else "Extinguishing"
 for bar in meters.get_children():
  bar.material_override=bar.material_override.duplicate()
  bar.material_override.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
  bar.material_override.no_depth_test=true
  bar.material_override.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
  bar.material_override.render_priority=2 if bar.name in ["Intensity","Extinguishing"] else 1
  bar.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 var crew=Node3D.new()
 crew.name="Crew"
 node.add_child(crew)
 for x in [-2.0,2.0]:
  var person=BeaverModels.create(1 if x<0 else 5,"fire")
  crew.add_child(person)
  person.position=Vector3(x,StreetSurface.ROAD_Y+0.02,12)
  person.rotation.y=PI
  person.get_node("LeftArm").rotation.x=-1.3
  person.get_node("RightArm").rotation.x=-1.3
  Models.box(person,Vector3(0.18,0.18,1.3),Vector3(0,1.5,0.8),Color("b9d5df"))
 var water=Node3D.new()
 water.name="Water"
 node.add_child(water)
 # Segmented parabolic water jets from the firefighters towards the facade.
 for side in [-2.0,2.0]:
  for i in 8:
   var t=float(i)/8
   var t2=float(i+1)/8
   var a=Vector3(side*(1-t),1.5+(roof-1.5)*t+3*sin(t*PI),11-10*t)
   var b=Vector3(side*(1-t2),1.5+(roof-1.5)*t2+3*sin(t2*PI),11-10*t2)
   var jet=Models.cylinder(water,0.10,a.distance_to(b),(a+b)*0.5,Color("9bdef4"))
   jet.quaternion=Quaternion(Vector3.UP,(b-a).normalized())
 var label=Label3D.new()
 label.layers=Models.WORLD_LABEL_LAYER
 label.name="Status"
 label.position=Vector3(0,roof+13,0)
 label.billboard=BaseMaterial3D.BILLBOARD_ENABLED
 label.font_size=24
 label.pixel_size=0.028
 label.modulate=Color("fff1d5")
 label.outline_size=4
 label.no_depth_test=true
 node.add_child(label)
 return node

func _process(delta: float) -> void:
 clock+=delta
 update_hydrants()
 var present={}
 for incident in Game.state.city_services.get("fires",[]):
  var id=int(incident.id)
  present[id]=true
  if not scenes.has(id):
   var home=Game.state.homes[int(incident.target_ref.index)]
   var roof=TownEvolution.floors(str(home.kind),int(home.level))*2.7+2.0
   scenes[id]=create_incident(roof)
   scenes[id].rotation_degrees.y=int(home.get("rotation",0))
  var node=scenes[id]
  node.position=CityServices.location(Game.state,incident.target_ref)
  var spraying=false
  var assigned={}
  var progress=float(incident.progress)
  for mission in Game.state.city_services.missions:
   if int(mission.get("fire_id",-1))==id:
    assigned=mission
    spraying=float(mission.age)>=float(mission.drive) and not mission.served
  if not assigned.is_empty():
   var arrival=node.to_local(LogisticsRoutes.vector(assigned.outward[-1]))
   var angle=atan2(arrival.x,arrival.z)
   node.get_node("Crew").rotation.y=angle
   node.get_node("Water").rotation.y=angle
  update_supply_hose(node,assigned,spraying)
  node.get_node("Crew").visible=spraying
  node.get_node("Water").visible=spraying
  var motion=bool(Game.state.ux.motion)
  var nearby=node.position.distance_to(world.view_focus)<world.view_zoom*1.6+40
  var particles_allowed=motion and Game.state.ambient_enabled and nearby
  var sparks=node.get_node("Sparks")
  var mist=node.get_node("WaterMist")
  var count=6 if Game.state.quality==0 else 18
  for emitter in [sparks,mist]:
   if emitter.amount!=count: emitter.amount=count
  sparks.gravity=sparks.global_basis.inverse()*(Atmosphere.wind(Game.state)*0.8+Vector3.UP*0.3)
  sparks.emitting=particles_allowed and progress<0.9
  sparks.visible=sparks.emitting
  mist.emitting=particles_allowed and spraying
  mist.visible=mist.emitting
  var glow=node.get_node("FireGlow")
  glow.visible=nearby and Game.state.quality>0
  glow.light_energy=(1-progress)*(0.8+0.1*sin(clock*5) if motion else 0.8)
  for jet in node.get_node("Water").get_children():
   jet.scale.x=1+0.12*sin(clock*13) if motion else 1.0
   jet.scale.z=jet.scale.x
  var meters=node.get_node("Meters")
  meters.get_node("Intensity").scale.x=maxf(0.001,1-progress)
  meters.get_node("Intensity").position.x=-3.85*progress
  meters.get_node("Extinguishing").scale.x=maxf(0.001,progress)
  meters.get_node("Extinguishing").position.x=-3.85*(1-progress)
  # Align the bars with the same camera-facing plane as their status caption.
  meters.rotation.y=world.camera.global_rotation.y-node.rotation.y
  for i in node.get_node("Flames").get_child_count():
   var flame=node.get_node("Flames").get_child(i)
   flame.material_override.set_shader_parameter("flame_clock",clock if motion else 0.0)
   flame.scale=Vector3.ONE*maxf(0.12,1-progress)*(1+0.12*sin(clock*7+i) if motion else 1.0)
  for i in node.get_node("Smoke").get_child_count():
   var puff=node.get_node("Smoke").get_child(i)
   puff.scale=Vector3.ONE*(0.55+i*0.16)*maxf(0.2,1-progress)
   if motion:
    var rise=fposmod(clock*0.9+i*1.8,10)
    var drift=Atmosphere.wind(Game.state)*rise*0.32
    drift=node.global_basis.inverse()*drift
    puff.position=Vector3(drift.x+sin(clock*0.7+i)*0.8,5+rise,drift.z+cos(i*2.1)*0.6)
   puff.visible=Game.state.quality!=0 or i<2
  node.get_node("Status").text="LÖSCHEN %s %%" % int(progress*100) if spraying else "FEUERWEHR · ANFAHRT" if int(incident.mission_id)>=0 else "RAUCH · ALARM IN %s s" % ceili(FireSafety.alarm_left(incident)) if FireSafety.alarm_left(incident)>0 else "BRAND · HILFE ANFORDERN"
  node.get_node("Status").text+="\nBRANDSTÄRKE %s %%" % int((1-progress)*100)
  var status=node.get_node("Status")
  # Keep the compact incident caption below the HUD, even when its smoke column
  # reaches the top of a narrow screen. The caption never changes incident state.
  status.position=Vector3(0,float(meters.get_meta("roof"))+13,0)
  var at=node.to_global(status.position)
  var screen=world.camera.unproject_position(at)
  var viewport_size=world.get_viewport().get_visible_rect().size
  var top=world.hud.mission_button.get_global_rect().end.y+132
  var bottom=world.hud.bottom_panel.get_global_rect().position.y-46
  var in_front=not world.camera.is_position_behind(at)
  var on_screen=screen.x>0 and screen.x<viewport_size.x and screen.y>0 and screen.y<viewport_size.y
  if in_front and on_screen and bottom>top:
   screen.y=clampf(screen.y,top,bottom)
   status.position=node.to_local(world.camera.project_position(screen,-world.camera.to_local(at).z))
  status.visible=in_front and on_screen and bottom>top and not world.hud.overlay.visible
  meters.position=status.position-Vector3(0,3,0)
  meters.visible=status.visible
  node.visible=nearby
 for id in scenes.keys():
  if not present.has(id):
   scenes[id].queue_free()
   scenes.erase(id)

func sphere(parent: Node3D, radius: float, at: Vector3, color: Color) -> MeshInstance3D:
 var node=MeshInstance3D.new()
 var mesh=SphereMesh.new()
 mesh.radius=radius
 mesh.height=radius*2
 mesh.radial_segments=10
 mesh.rings=5
 node.mesh=mesh
 node.position=at
 node.material_override=Models.material(color)
 parent.add_child(node)
 return node

func update_hydrants() -> void:
 var installations=[]
 for i in Game.state.homes.size():
  if FireSafety.installed(Game.state,i,"hydrant"): installations.append([i,LogisticsRoutes.home_position(Game.state,i),int(Game.state.homes[i].get("rotation",0))])
 var signature=[installations,hash(Game.state.town.roads),int(Game.state.town.districts)]
 if signature!=protection_signature:
  for node in hydrants.values():
   remove_child(node)
   node.queue_free()
  hydrants.clear()
  var cells=TownRules.road_cells(Game.state.town)
  for item in installations:
   var node=Node3D.new()
   node.name="Hydrant_%s" % item[0]
   add_child(node)
   node.position=FireSafety.hydrant_position(Game.state,int(item[0]),cells)
   Models.cylinder(node,0.65,0.18,Vector3(0,0.05,0),Color("a3b1af"))
   Models.cylinder(node,0.42,1.55,Vector3(0,0.9,0),Color("c84132"))
   Models.cylinder(node,0.53,0.3,Vector3(0,1.75,0),Color("f0c269"))
   Models.box(node,Vector3(1.5,0.35,0.4),Vector3(0,1.2,0),Color("c84132"))
   for side in [-0.78,0.78]: Models.box(node,Vector3(0.16,0.42,0.45),Vector3(side,1.2,0),Color("d7dbcf"))
   Models.bake(node)
   hydrants[int(item[0])]=node
  protection_signature=signature.duplicate(true)
 for node in hydrants.values(): node.visible=node.position.distance_to(world.view_focus)<world.view_zoom*1.5+35

func update_supply_hose(node: Node3D, mission: Dictionary, spraying: bool) -> void:
 var hose=node.get_node_or_null("SupplyHose")
 if mission.is_empty() or mission.get("water_source_ref",{}).is_empty():
  if hose!=null: hose.hide()
  return
 if hose==null:
  hose=Node3D.new()
  hose.name="SupplyHose"
  node.add_child(hose)
  var ref=mission.water_source_ref
  var points=[FireSafety.hydrant_position(Game.state,int(ref.index))+Vector3(0,0.9,0)]
  for point in mission.get("water_route",[]):
   var p=LogisticsRoutes.vector(point)
   p.y=1.05
   points.append(p)
  points.append(LogisticsRoutes.vector(mission.outward[-1])+Vector3(0,0.5,0))
  for i in mini(96,points.size()-1):
   var a=node.to_local(points[i])
   var b=node.to_local(points[i+1])
   if a.distance_to(b)<0.01: continue
   var tube=Models.cylinder(hose,0.12,a.distance_to(b),(a+b)*0.5,Color("e1c76d"))
   tube.quaternion=Quaternion(Vector3.UP,(b-a).normalized())
  Models.bake(hose)
 hose.visible=spraying

func flame_mesh() -> ArrayMesh:
 # Irregular curved lobes with a hot base; no traffic-cone silhouette.
 var surface=SurfaceTool.new()
 surface.begin(Mesh.PRIMITIVE_TRIANGLES)
 var radii=[0.35,0.85,0.62,0.46,0.28,0.12,0.015]
 for row in 6:
  for side in 8:
   var vertices=[]
   for corner in [[row,side],[row+1,side],[row+1,side+1],[row,side+1]]:
    var h=float(corner[0])/6.0
    var angle=float(corner[1])*TAU/8.0+h*0.65
    var radius=float(radii[int(corner[0])])*(1+0.14*sin(angle*3+h*4))
    vertices.append(Vector3(cos(angle)*radius+sin(h*4)*0.3,h*4.8,sin(angle)*radius))
   for index in [0,1,2,0,2,3]: surface.add_vertex(vertices[index])
 surface.generate_normals()
 return surface.commit()
